#ifndef CUBO_H_INCLUDED
#define CUBO_H_INCLUDED

struct  Cubo
{
    float a, area, volume;
    //construtor
    Cubo(float a){
        this->a = a;
    }
};



#endif