#include <iostream>
#include "pratica.3.3.h"

using namespace std;

int main () {

Data d1 (13 , 12 , 2021) ;

d1 . exibirDataFormatoNumero () ;
d1 . exibirDataPorExtenso () ;
d1 . getDataEmSegundos () ;
return 0;
}